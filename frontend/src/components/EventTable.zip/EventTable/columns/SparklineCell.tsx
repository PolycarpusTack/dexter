import React from 'react';
import { Box, Skeleton, Text, useMantineTheme } from '@mantine/core';
import { Sparkline } from '@mantine/charts';

// Custom hooks
import { useEventFrequency } from '../../../hooks/useEventFrequency';

// Types
import { EventType } from '../../../types/eventTypes';

interface SparklineCellProps {
  eventData: EventType;
  timeRange?: '24h' | '7d' | '30d';
}

/**
 * SparklineCell Component
 * 
 * Displays a mini sparkline visualization of event frequency over time.
 * Shows trends and highlights significant points.
 * 
 * @param {SparklineCellProps} props - Component properties
 */
export const SparklineCell: React.FC<SparklineCellProps> = ({ 
  eventData, 
  timeRange = '24h' 
}) => {
  const theme = useMantineTheme();
  const { data, isLoading } = useEventFrequency(eventData.id, timeRange);
  
  if (isLoading) {
    return <Skeleton width={120} height={30} />;
  }
  
  // Fallback for no data
  if (!data || !data.points || data.points.length === 0) {
    return (
      <Box w={120} h={40} display="flex" alignItems="center">
        <Text size="xs" c="dimmed">No data available</Text>
      </Box>
    );
  }
  
  // Define color based on trend
  const trendColor = data.trend > 0 
    ? theme.colors.red[6] 
    : data.trend < 0 
      ? theme.colors.green[6] 
      : theme.colors.gray[6];
  
  return (
    <Box w={120} h={40}>
      <Sparkline
        data={data.points}
        w={120}
        h={25}
        color={trendColor}
      />
      <Text size="xs" c="dimmed" align="right">
        {data.trend > 0 
          ? `↑ ${data.trend}%` 
          : data.trend < 0 
            ? `↓ ${Math.abs(data.trend)}%` 
            : `–`}
      </Text>
    </Box>
  );
};

export default SparklineCell;