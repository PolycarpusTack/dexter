// File: frontend/src/components/EventTable/columns/index.js

export { default as SparklineCell } from './SparklineCell';
export { default as ImpactCell } from './ImpactCell';
export { default as DeadlockColumn } from './DeadlockColumn';
