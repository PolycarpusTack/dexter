import React from 'react';
import { Badge, Box, Group, Progress, Text, Tooltip } from '@mantine/core';
import { IconUsers } from '@tabler/icons-react';
import { EventType } from '../../../types/eventTypes';

interface ImpactCellProps {
  eventData: EventType;
  maxImpact?: number;
}

/**
 * ImpactCell Component
 * 
 * Displays user impact metrics for an event
 */
export const ImpactCell: React.FC<ImpactCellProps> = ({
  eventData,
  maxImpact = 1000
}) => {
  // Check if impact data is available
  if (!eventData.userImpact) {
    return (
      <Text color="dimmed" size="sm">No impact data</Text>
    );
  }
  
  const { count, percentage } = eventData.userImpact;
  
  // Determine severity level
  let severity: 'low' | 'medium' | 'high' | 'critical';
  let color: string;
  
  if (percentage < 0.5) {
    severity = 'low';
    color = 'blue';
  } else if (percentage < 2) {
    severity = 'medium';
    color = 'yellow';
  } else if (percentage < 5) {
    severity = 'high';
    color = 'orange';
  } else {
    severity = 'critical';
    color = 'red';
  }
  
  // Calculate progress percentage (capped at 100%)
  const progressValue = Math.min((count / maxImpact) * 100, 100);
  
  return (
    <Box>
      <Group spacing="xs" mb={4}>
        <IconUsers size={14} />
        <Text size="sm" fw={500}>
          {count.toLocaleString()}
        </Text>
        <Tooltip label={`${percentage.toFixed(2)}% of users affected`}>
          <Badge color={color} variant="light" size="xs">
            {percentage.toFixed(1)}%
          </Badge>
        </Tooltip>
      </Group>
      <Progress 
        value={progressValue} 
        color={color} 
        size="xs" 
        radius="xl"
      />
    </Box>
  );
};

export default ImpactCell;