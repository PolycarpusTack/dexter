import React from 'react';
import { Badge, Box, Group, Text, Tooltip } from '@mantine/core';
import { EventType } from '../../../types/eventTypes';

interface SummaryCellProps {
  eventData: EventType;
  maxLength?: number;
}

/**
 * SummaryCell Component
 * 
 * Displays a concise summary of the event details
 */
export const SummaryCell: React.FC<SummaryCellProps> = ({
  eventData,
  maxLength = 100
}) => {
  // Format summary text
  const summaryText = eventData.message || eventData.title || 'No description available';
  
  // Truncate if needed
  const displayText = summaryText.length > maxLength
    ? `${summaryText.substring(0, maxLength)}...`
    : summaryText;
  
  // Extract important tags (limit to 3 for display)
  const maxTags = 2;
  const hasMoreTags = (eventData.tags?.length || 0) > maxTags;
  const displayTags = eventData.tags?.slice(0, maxTags) || [];
  
  return (
    <Box>
      <Tooltip 
        label={summaryText} 
        disabled={summaryText.length <= maxLength}
      >
        <Text size="sm" lineClamp={2}>
          {displayText}
        </Text>
      </Tooltip>
      
      {displayTags.length > 0 && (
        <Group spacing="xs" mt={4}>
          {displayTags.map((tag, index) => {
            // Handle different tag formats (string or object)
            let displayValue = '';
            
            if (typeof tag === 'string') {
              // Handle string tags (potentially with key:value format)
              const tagParts = tag.includes(':') ? tag.split(':') : [tag, ''];
              displayValue = tagParts[1] || tagParts[0];
            } else if (typeof tag === 'object' && tag !== null) {
              // Handle object tags
              if (tag.value !== undefined) {
                // If tag has a value property, use it directly
                displayValue = String(tag.value);
              } else if (tag.key !== undefined && tag.name !== undefined) {
                // If tag has both key and name, use them together
                displayValue = String(tag.name);
              } else if (tag.name !== undefined) {
                // If tag just has a name, use it
                displayValue = String(tag.name);
              } else if (tag.key !== undefined) {
                // If tag just has a key, use it
                displayValue = String(tag.key);
              } else {
                // For any other object, try to extract a meaningful string representation
                // First look for common property names that might contain the value
                const possibleValueProps = ['id', 'title', 'label', 'text', 'type', 'browser', 'os', 'device'];
                
                for (const prop of possibleValueProps) {
                  if (prop in tag && tag[prop] !== undefined && tag[prop] !== null) {
                    displayValue = String(tag[prop]);
                    break;
                  }
                }
                
                // If still no display value, take the first non-object property
                if (!displayValue) {
                  const keys = Object.keys(tag);
                  for (const key of keys) {
                    const val = tag[key];
                    if (val !== null && typeof val !== 'object') {
                      displayValue = String(val);
                      break;
                    }
                  }
                }
                
                // Last resort: use first property name
                if (!displayValue && keys && keys.length > 0) {
                  displayValue = keys[0];
                }
              }
              
              // If somehow we still don't have a display value, use a default
              if (!displayValue) {
                displayValue = 'Tag';
              }
            } else {
              // Fallback for any other type
              displayValue = String(tag || 'Tag');
            }
            
            return (
              <Badge
                key={index}
                size="xs"
                variant="light"
              >
                {displayValue}
              </Badge>
            );
          })}
          
          {hasMoreTags && (
            <Badge size="xs" variant="outline">
              +{(eventData.tags?.length || 0) - maxTags} more
            </Badge>
          )}
        </Group>
      )}
    </Box>
  );
};

export default SummaryCell;