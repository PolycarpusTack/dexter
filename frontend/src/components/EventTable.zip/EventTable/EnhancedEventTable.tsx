import React, { useCallback, useEffect, useMemo, useState, forwardRef, useImperativeHandle } from 'react';
import { TableVirtuoso } from 'react-virtuoso';
import { useHotkeys } from '@mantine/hooks';
import { Badge, Box, Button, Group, Menu, Paper, Select, Text, TextInput, Transition } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { IconFilter, IconSearch, IconSortAscending, IconSortDescending, IconTag, IconUser } from '@tabler/icons-react';
import { useQueryClient } from '@tanstack/react-query';
import { Sparkline } from '@mantine/charts';
import { useSearchParams } from 'react-router-dom';

// Import custom hooks and utilities
import useAppStore from '../../store/appStore';
import { useEventData } from '../../hooks/useEventData';
import { useIssueActions } from '../../hooks/useIssueActions';
import { useClipboard } from '../../hooks/useClipboard';
import { useDataMasking } from '../../hooks/useDataMasking';
import { useAuditLog } from '../../hooks/useAuditLog';
import { useKeyboardNavigation } from '../../hooks/useKeyboardNavigation';
import { useSearchParamState } from '../../hooks/useSearchParamState';

// Import types and schemas
import { EventType, SortDirection, TimeRange } from '../../types/eventTypes';
import { safeValidateEventResponse } from '../../schemas/eventSchemas';

// Import components
import LoadingSkeleton from '../UI/LoadingSkeleton';
import { ErrorBoundary } from '../ErrorHandling';
import { EventRow } from './EventRow';
import { BulkActionBar } from './bulk-actions/BulkActionBar';
import { FilterControls } from './filters/FilterControls';
import { SmartSearch } from './filters/SmartSearch';
import { TagCloud } from './TagCloud';
import { SparklineCell } from './columns/SparklineCell';
import { ImpactCell } from './columns/ImpactCell';
import { SummaryCell } from './columns/SummaryCell';

// API clients
import { fetchEvents, listenForEvents } from '../../api/eventApi';
import { calculateTotalImpact, mergeEvents } from '../../utils/eventUtils';

// Define component props with strict TypeScript types
interface EnhancedEventTableProps {
  projectId?: string;
  timeRange?: TimeRange;
  initialFilters?: Record<string, unknown>;
  onEventSelect?: (event: EventType) => void;
  onError?: (error: Error) => void;
  showControls?: boolean;
  maxHeight?: number | string;
  autoRefresh?: boolean;
}

/**
 * Enhanced Event Table Component
 * 
 * An enterprise-grade table component for displaying and interacting with Sentry events.
 * Features include:
 * - Virtualized windowing for handling large datasets
 * - Real-time updates via WebSockets
 * - Advanced filtering and sorting
 * - Keyboard navigation
 * - Bulk actions
 * - Accessibility support
 * 
 * @param {EnhancedEventTableProps} props - Component properties
 */
export const EnhancedEventTable = forwardRef<any, EnhancedEventTableProps>(({
  projectId,
  timeRange = '24h',
  initialFilters = {},
  onEventSelect,
  onError,
  showControls = true,
  maxHeight = 'calc(100vh - 200px)',
  autoRefresh = false
}, ref) => {
  // URL-based state for persistence
  const [searchParams, setSearchParams] = useSearchParams();
  const [sortField, setSortField] = useSearchParamState('sort', 'timestamp');
  const [sortDirection, setSortDirection] = useSearchParamState<SortDirection>('dir', 'desc');
  const [secondarySortField, setSecondarySortField] = useSearchParamState('sort2', '');
  
  // Local state for UI interaction
  const [selectedEvents, setSelectedEvents] = useState<EventType[]>([]);
  const [activeRowIndex, setActiveRowIndex] = useState<number>(-1);
  const [filterDialogOpen, { toggle: toggleFilterDialog }] = useDisclosure(false);
  
  // Get state from app store
  const search = useAppStore(state => state.searchQuery);
  const theme = 'light'; // Default theme if not available in store
  const setSearch = useCallback((value: string) => {
    useAppStore.getState().setSearchQuery(value);
  }, []);
  
  // Get organization and project from global state if not provided
  const organizationIdFromStore = useAppStore(state => state.organizationSlug);
  const projectIdFromStore = useAppStore(state => state.projectSlug);
  
  // Use provided projectId prop or fall back to store value
  const effectiveProjectId = projectId || projectIdFromStore;
  const effectiveOrgId = organizationIdFromStore;
  
  // Access shared functionality through custom hooks
  const { focusableRef, handleKeyNavigation } = useKeyboardNavigation<HTMLDivElement>();
  const logEvent = useAuditLog('EnhancedEventTable');
  const queryClient = useQueryClient();
  
  // Prepare filter and sort parameters for API request
  const apiParams = useMemo(() => ({
    organizationId: effectiveOrgId || 'default',
    projectId: effectiveProjectId || 'default',
    timeRange,
    sort: secondarySortField 
      ? `${sortField}:${sortDirection},${secondarySortField}:${sortDirection}` 
      : `${sortField}:${sortDirection}`,
    query: search,
    ...initialFilters,
    ...(Object.fromEntries(searchParams.entries())), // Include URL params
  }), [effectiveOrgId, effectiveProjectId, timeRange, sortField, sortDirection, secondarySortField, search, initialFilters, searchParams]);
  
  // Fetch data using React Query
  const { 
    data, 
    isLoading, 
    isError, 
    error, 
    refetch,
    isFetching
  } = useEventData(apiParams);
  
  // Expose refetch method via ref
  useImperativeHandle(ref, () => ({
    refresh: refetch
  }));
  
  // Real-time WebSocket connection for live updates
  useEffect(() => {
    if (!effectiveProjectId) return;
    
    // Initialize WebSocket connection
    const unsubscribe = listenForEvents(effectiveProjectId, (newEvents) => {
      queryClient.setQueryData(['events', apiParams], (oldData: any) => {
        if (!oldData) return oldData;
        return mergeEvents(oldData, newEvents);
      });
    });
    
    return () => {
      unsubscribe();
    };
  }, [effectiveProjectId, queryClient, apiParams]);
  
  // Auto refresh if enabled
  useEffect(() => {
    if (!autoRefresh) return;
    
    const interval = setInterval(() => {
      refetch();
    }, 30000); // Refresh every 30 seconds
    
    return () => clearInterval(interval);
  }, [autoRefresh, refetch]);
  
  // Error handling effect
  useEffect(() => {
    if (isError && error && onError) {
      onError(error as Error);
    }
  }, [isError, error, onError]);
  
  // Log important interactions
  useEffect(() => {
    logEvent('loaded', { 
      projectId: effectiveProjectId, 
      resultsCount: data?.items?.length || 0,
      timeRange 
    });
  }, [logEvent, effectiveProjectId, data?.items?.length, timeRange]);
  
  // Selection management for bulk actions
  const toggleSelection = useCallback((event: EventType) => {
    setSelectedEvents(prev => {
      const isSelected = prev.some(e => e.id === event.id);
      return isSelected 
        ? prev.filter(e => e.id !== event.id) 
        : [...prev, event];
    });
  }, []);
  
  // Clear selection when data changes
  useEffect(() => {
    setSelectedEvents([]);
  }, [effectiveProjectId, timeRange]);
  
  // Handle sort direction toggle
  const toggleSortDirection = useCallback(() => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  }, [setSortDirection]);
  
  // Handle sort field change
  const handleSortChange = useCallback((field: string) => {
    if (field === sortField) {
      toggleSortDirection();
    } else {
      setSecondarySortField(sortField);
      setSortField(field);
      setSortDirection('desc');
    }
  }, [sortField, setSortField, setSecondarySortField, setSortDirection, toggleSortDirection]);
  
  // Handle search input change
  const handleSearchChange = useCallback((value: string) => {
    setSearch(value);
    logEvent('search', { query: value });
  }, [setSearch, logEvent]);
  
  // Handle row click
  const handleRowClick = useCallback((event: EventType) => {
    // Update the application store
    useAppStore.getState().setSelectedIssue(event.id);
    
    // Call the prop callback if provided
    if (onEventSelect) {
      onEventSelect(event);
    }
    
    logEvent('rowSelected', { eventId: event.id });
  }, [onEventSelect, logEvent]);
  
  // Setup keyboard shortcuts
  useHotkeys([
    ['/', () => document.getElementById('event-search')?.focus()],
    ['escape', () => setSelectedEvents([])],
    ['ctrl+a', () => {
      if (data?.items) {
        setSelectedEvents(prev => 
          prev.length === data.items.length ? [] : [...data.items]
        );
      }
      return false; // Prevent default browser behavior
    }],
    ['arrowup, k', () => handleKeyNavigation('up', data?.items?.length || 0, setActiveRowIndex)],
    ['arrowdown, j', () => handleKeyNavigation('down', data?.items?.length || 0, setActiveRowIndex)],
    ['enter', () => {
      if (activeRowIndex >= 0 && data?.items && data.items[activeRowIndex]) {
        handleRowClick(data.items[activeRowIndex]);
      }
      return false;
    }]
  ]);
  
  // Create tag cloud data for visualization
  const tagCloud = useMemo(() => 
    data?.items?.reduce((acc: Record<string, number>, event: EventType) => {
      (event.tags || []).forEach(tag => {
        if (tag.includes(':')) {
          acc[tag] = (acc[tag] || 0) + 1;
        }
      });
      return acc;
    }, {}) || {},
  [data?.items]);
  
  // Use a callback for row rendering to optimize virtualization
  const rowRenderer = useCallback((index: number) => {
    const event = data?.items?.[index];
    if (!event) return null;
    
    const isSelected = selectedEvents.some(e => e.id === event.id);
    const isActive = index === activeRowIndex;
    
    return (
      <EventRow 
        event={event}
        isSelected={isSelected}
        isActive={isActive}
        onClick={() => handleRowClick(event)}
        onSelect={() => toggleSelection(event)}
      />
    );
  }, [data?.items, selectedEvents, activeRowIndex, handleRowClick, toggleSelection]);
  
  // Handle bulk actions (via callback to prevent unnecessary re-renders)
  const { bulkUpdate, isUpdating } = useIssueActions();
  
  // Render loading state
  if (isLoading) {
    return <LoadingSkeleton type="table" rows={10} />;
  }
  
  // Render error state
  if (isError && error) {
    return (
      <Paper p="md" radius="md" withBorder>
        <Text color="red">Error loading events: {(error as Error).message}</Text>
        <Button mt="md" onClick={() => refetch()}>Retry</Button>
      </Paper>
    );
  }
  
  return (
    <ErrorBoundary fallback={<Text color="red">Something went wrong rendering the event table</Text>}>
      <Box>
        {showControls && (
          <Group justify="space-between" mb="md">
            <Group>
              <SmartSearch
                value={search}
                onChange={handleSearchChange}
                onAdvancedClick={toggleFilterDialog}
                placeholder="Search events..."
              />
            </Group>
            <Group>
              <Select
                placeholder="Sort by"
                data={[
                  { value: 'timestamp', label: 'Date' },
                  { value: 'count', label: 'Frequency' },
                  { value: 'userImpact.count', label: 'User Impact' },
                  { value: 'level', label: 'Error Level' }
                ]}
                value={sortField}
                onChange={(val) => val && handleSortChange(val)}
                width={140}
              />
              <Button
                variant="subtle"
                onClick={toggleSortDirection}
                leftSection={
                  sortDirection === 'asc' 
                    ? <IconSortAscending size={14} /> 
                    : <IconSortDescending size={14} />
                }
                aria-label={sortDirection === 'asc' ? 'Sort ascending' : 'Sort descending'}
              >
                {sortDirection === 'asc' ? 'Asc' : 'Desc'}
              </Button>
            </Group>
          </Group>
        )}
        
        {filterDialogOpen && (
          <FilterControls 
            onClose={toggleFilterDialog}
            onFilter={(filters) => {
              // Update URL params with new filters
              const newParams = new URLSearchParams(searchParams);
              Object.entries(filters).forEach(([key, value]) => {
                if (value) {
                  newParams.set(key, value.toString());
                } else {
                  newParams.delete(key);
                }
              });
              setSearchParams(newParams);
            }}
            initialFilters={Object.fromEntries(searchParams.entries())}
          />
        )}
        
        {Object.keys(tagCloud).length > 0 && (
          <Box mb="md">
            <Text size="sm" weight={500} mb="xs">Trending Tags:</Text>
            <TagCloud 
              tags={tagCloud} 
              maxSize={24} 
              minSize={12} 
              onTagClick={(tag) => {
                // Add tag to search if clicked
                const tagPrefix = tag.split(':')[0];
                const searchValue = search ? `${search} tag:${tag}` : `tag:${tag}`;
                handleSearchChange(searchValue);
              }}
            />
          </Box>
        )}
        
        {/* Bulk action bar with transition */}
        <Transition 
          mounted={selectedEvents.length > 0} 
          transition="slide-up"
          duration={200}
        >
          {(styles) => (
            <BulkActionBar 
              style={styles}
              selectedEvents={selectedEvents}
              onClearSelection={() => setSelectedEvents([])}
              totalImpact={calculateTotalImpact(selectedEvents)}
            />
          )}
        </Transition>
        
        {/* Main table with virtualization */}
        <Box 
          ref={focusableRef}
          tabIndex={0}
          style={{ outline: 'none' }}
          h={maxHeight}
        >
          {data?.items && data.items.length > 0 ? (
            <TableVirtuoso
              data={data.items}
              totalCount={data.items.length}
              overscan={500}
              style={{ height: typeof maxHeight === 'number' ? maxHeight : maxHeight }}
              fixedHeaderContent={() => (
                <tr>
                  <th style={{ width: 40 }}></th>
                  <th>Event</th>
                  <th style={{ width: 150 }}>Impact</th>
                  <th style={{ width: 120 }}>Trend</th>
                  <th style={{ width: 160 }}>Last Seen</th>
                  <th style={{ width: 100 }}>Actions</th>
                </tr>
              )}
              itemContent={rowRenderer}
              components={{
                Table: (props) => <table {...props} style={{ width: '100%', borderCollapse: 'collapse' }} />,
                TableRow: (props) => <tr {...props} style={{ borderBottom: `1px solid ${theme === 'dark' ? '#2C2E33' : '#E9ECEF'}` }} />
              }}
            />
          ) : (
            <Paper p="xl" radius="md" withBorder>
              <Text align="center">No events found matching your criteria</Text>
            </Paper>
          )}
        </Box>
        
        {/* Loading indicator for subsequent data fetches */}
        {isFetching && !isLoading && (
          <Text size="sm" mt="sm" color="dimmed" align="center">
            Refreshing data...
          </Text>
        )}
      </Box>
    </ErrorBoundary>
  );
});

// Add display name for better debugging
EnhancedEventTable.displayName = "EnhancedEventTable";

export default EnhancedEventTable;