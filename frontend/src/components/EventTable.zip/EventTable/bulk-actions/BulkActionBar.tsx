import React, { useState } from 'react';
import { Badge, Button, Group, Menu, Paper, Select, Text } from '@mantine/core';
import { IconTag, IconUser, IconBrandGithub } from '@tabler/icons-react';

// Custom hooks
import { useIssueActions } from '../../../hooks/useIssueActions';

// Types
import { EventType } from '../../../types/eventTypes';

// Constants
const STATUS_OPTIONS = [
  { value: 'unresolved', label: 'Unresolved' },
  { value: 'resolved', label: 'Resolved' },
  { value: 'ignored', label: 'Ignored' }
];

interface BulkActionBarProps {
  selectedEvents: EventType[];
  onClearSelection: () => void;
  totalImpact: number;
  style?: React.CSSProperties;
}

/**
 * BulkActionBar Component
 * 
 * Provides bulk action capabilities for selected events.
 * Displays selection count, total impact, and action options.
 * 
 * @param {BulkActionBarProps} props - Component properties
 */
export const BulkActionBar: React.FC<BulkActionBarProps> = ({
  selectedEvents,
  onClearSelection,
  totalImpact,
  style = {}
}) => {
  const [status, setStatus] = useState<string>('');
  const { bulkUpdate, isUpdating } = useIssueActions();
  
  // Handle bulk status update
  const handleStatusUpdate = async () => {
    if (!status) return;
    
    try {
      await bulkUpdate(selectedEvents, { status });
      onClearSelection();
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };
  
  // Handle tag dialog
  const openTagDialog = () => {
    // Implementation would open a modal for tag selection
    console.log('Open tag dialog for', selectedEvents.map(e => e.id));
  };
  
  // Handle assign dialog
  const openAssignDialog = () => {
    // Implementation would open a modal for user assignment
    console.log('Open assign dialog for', selectedEvents.map(e => e.id));
  };
  
  // Handle GitHub issue creation
  const createGithubIssue = () => {
    // Implementation would trigger GitHub issue creation API
    console.log('Create GitHub issue for', selectedEvents.map(e => e.id));
  };
  
  return (
    <Paper 
      p="sm" 
      shadow="md" 
      mb="md"
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 10,
        ...style
      }}
    >
      <Group position="apart">
        <Group>
          <Badge size="lg">
            {selectedEvents.length} selected
          </Badge>
          <Text size="sm">
            Impact: {totalImpact.toLocaleString()} users
          </Text>
        </Group>
        <Group>
          <Select
            placeholder="Set status"
            data={STATUS_OPTIONS}
            value={status}
            onChange={(val) => setStatus(val || '')}
            w={140}
            clearable
          />
          <Button 
            onClick={handleStatusUpdate}
            loading={isUpdating}
            disabled={!status}
          >
            Apply
          </Button>
          <Menu shadow="md" width={200}>
            <Menu.Target>
              <Button variant="light">
                More Actions
              </Button>
            </Menu.Target>
            <Menu.Dropdown>
              <Menu.Item 
                leftSection={<IconTag size={14} />}
                onClick={openTagDialog}
              >
                Add tags
              </Menu.Item>
              <Menu.Item 
                leftSection={<IconUser size={14} />}
                onClick={openAssignDialog}
              >
                Assign to...
              </Menu.Item>
              <Menu.Item 
                leftSection={<IconBrandGithub size={14} />}
                onClick={createGithubIssue}
              >
                Create GitHub issue
              </Menu.Item>
              <Menu.Divider />
              <Menu.Item 
                color="red"
                onClick={onClearSelection}
              >
                Clear selection
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        </Group>
      </Group>
    </Paper>
  );
};

export default BulkActionBar;