import React, { useMemo } from 'react';
import { Badge, Box, Group } from '@mantine/core';

// Utilities for tag handling
import { getTagColor, parseTag } from '../../utils/tagUtils';

interface TagCloudProps {
  tags: Record<string, number>;
  maxSize?: number;
  minSize?: number;
  maxTags?: number;
  onTagClick?: (tag: string) => void;
}

/**
 * Simple TagCloud component
 * 
 * Displays tags with size based on frequency
 */
export const TagCloud: React.FC<TagCloudProps> = ({
  tags,
  maxSize = 24,
  minSize = 12,
  maxTags = 25,
  onTagClick
}) => {
  // Process tags to determine sizes and sort by frequency
  const processedTags = useMemo(() => {
    // Convert to array for sorting
    const tagEntries = Object.entries(tags);
    
    // Sort by frequency (descending)
    const sortedTags = tagEntries.sort((a, b) => b[1] - a[1]);
    
    // Limit to max tags
    return sortedTags.slice(0, maxTags);
  }, [tags, maxTags]);
  
  if (processedTags.length === 0) {
    return null;
  }
  
  return (
    <Box>
      <Group spacing="xs">
        {processedTags.map(([tagKey, count]) => {
          // Try to parse the tag if it's in key:value format
          let category = 'default';
          let displayText = tagKey;
          
          try {
            // Handle string tags in "key:value" format
            if (typeof tagKey === 'string' && tagKey.includes(':')) {
              const parts = tagKey.split(':');
              category = parts[0];
              displayText = parts.length > 1 ? `${parts[0]}: ${parts.slice(1).join(':')}` : tagKey;
            } else {
              // For other formats, use the tag utilities
              const parsed = parseTag(tagKey);
              category = parsed.key;
              displayText = parsed.value ? `${parsed.key}: ${parsed.value}` : parsed.key;
            }
          } catch (e) {
            // Fallback in case of parsing errors
            console.warn('Error parsing tag:', tagKey, e);
            category = 'default';
            displayText = String(tagKey);
          }
          
          return (
            <Badge
              key={tagKey}
              color={getTagColor(category, { colors: { blue: {} } } as any)}
              variant="light"
              style={{
                cursor: onTagClick ? 'pointer' : 'default'
              }}
              onClick={onTagClick ? () => onTagClick(tagKey) : undefined}
              size="sm"
            >
              {displayText} ({count})
            </Badge>
          );
        })}
      </Group>
    </Box>
  );
};

export default TagCloud;