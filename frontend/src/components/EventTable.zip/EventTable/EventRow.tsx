import React, { memo } from 'react';
import { ActionIcon, Box, Checkbox, Group, Text, useMantineTheme } from '@mantine/core';
import { IconExternalLink } from '@tabler/icons-react';
import { format, formatDistanceToNow } from 'date-fns';

// Components
import { SparklineCell } from './columns/SparklineCell';
import { ImpactCell } from './columns/ImpactCell';
import { SummaryCell } from './columns/SummaryCell';

// Types
import { EventType } from '../../types/eventTypes';

interface EventRowProps {
  event: EventType;
  isSelected: boolean;
  isActive: boolean;
  onClick: () => void;
  onSelect: () => void;
}

/**
 * EventRow Component
 * 
 * Displays a single event row with optimized rendering.
 * Handles selection, highlighting, and displays critical event data.
 * 
 * @param {EventRowProps} props - Component properties
 */
export const EventRow: React.FC<EventRowProps> = memo(({
  event,
  isSelected,
  isActive,
  onClick,
  onSelect
}) => {
  const theme = useMantineTheme();
  
  // Format timestamp
  const formattedDate = event.timestamp 
    ? format(new Date(event.timestamp), 'MMM d, yyyy HH:mm:ss')
    : 'Unknown date';
  
  // Format relative time
  const relativeTime = event.timestamp
    ? formatDistanceToNow(new Date(event.timestamp), { addSuffix: true })
    : 'Unknown';
  
  // Determine row styling based on selection and active state
  const rowStyle = {
    cursor: 'pointer',
    backgroundColor: isSelected 
      ? theme.colorScheme === 'dark' 
        ? theme.colors.blue[9] 
        : theme.colors.blue[0]
      : isActive
        ? theme.colorScheme === 'dark'
          ? theme.colors.dark[5]
          : theme.colors.gray[1]
        : 'transparent',
    ':hover': {
      backgroundColor: theme.colorScheme === 'dark'
        ? theme.colors.dark[6]
        : theme.colors.gray[1]
    }
  };
  
  // Handle checkbox click without triggering row click
  const handleCheckboxClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect();
  };
  
  return (
    <tr 
      style={rowStyle} 
      onClick={onClick}
      aria-selected={isSelected}
    >
      <td>
        <Checkbox 
          checked={isSelected}
          onChange={() => {}} // Controlled component
          onClick={handleCheckboxClick}
          aria-label={`Select event ${event.id}`}
        />
      </td>
      <td>
        <Box>
          <Text fw={500} size="sm" lineClamp={1}>
            {event.title || 'Untitled Event'}
          </Text>
          <SummaryCell eventData={event} />
        </Box>
      </td>
      <td>
        <ImpactCell eventData={event} />
      </td>
      <td>
        <SparklineCell eventData={event} />
      </td>
      <td>
        <Box>
          <Text size="sm">{relativeTime}</Text>
          <Text size="xs" c="dimmed">{formattedDate}</Text>
        </Box>
      </td>
      <td>
        <Group spacing="xs">
          <ActionIcon 
            variant="subtle"
            onClick={(e) => {
              e.stopPropagation();
              window.open(`/events/${event.id}`, '_blank');
            }}
            aria-label="Open in new tab"
          >
            <IconExternalLink size={16} />
          </ActionIcon>
        </Group>
      </td>
    </tr>
  );
});

// Add display name for better debugging
EventRow.displayName = 'EventRow';

export default EventRow;