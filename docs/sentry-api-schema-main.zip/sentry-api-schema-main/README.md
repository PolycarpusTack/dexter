# Sentry's API Schema

Sentry's public API schema uses [OpenAPI](https://swagger.io/specification/) v3.0.1.

This repository is an artifact used while deploying the API schema. The source of truth can be found in [Sentry](https://github.com/getsentry/sentry/tree/master/api-docs), along with the [tests](https://github.com/getsentry/sentry/tree/master/tests/apidocs). Do not create PRs against this repository!
